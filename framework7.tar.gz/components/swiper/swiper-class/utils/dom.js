import $ from 'dom7';

export default $;
